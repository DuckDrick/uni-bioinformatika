CODONS = {
    'start': ['ATG'],
    'stop': ['TAA', 'TAG', 'TGA'],
}

from curses import qiflush
from math import sqrt
from Bio import SeqIO;
import re;
import numpy

def findSubstringLocation(a_str, sub):
    locations = [];
    start = 0
    while True:
        start = a_str.find(sub, start)
        if start == -1:
            break;
        locations.append(start);
        start += len(sub);
    return locations;

def groupByOffset(locations):
    zero = filter(lambda l: l % 3 == 0 ,locations);
    one = filter(lambda l: l % 3 == 1 ,locations);
    two = filter(lambda l: l % 3 == 2 ,locations);
    return [list(zero), list(one), list(two)];

def findCodonPairs(sequence):
    starts = [];
    
    for codon in CODONS['start']:
        starts.append(findSubstringLocation(sequence, codon))


    stops = [];
    
    for codon in CODONS['stop']:
        stops.append(findSubstringLocation(sequence, codon))

    starts = [item for sublist in starts for item in sublist]
    stops = [item for sublist in stops for item in sublist]

    starts.sort();
    stops.sort();

    starts = groupByOffset(starts)
    stops = groupByOffset(stops)


    rezults = [];
    for offset in range(3):
        rez = {}
        startIndex = 0;
        stopIndex = 0;

        startPositions = starts[offset];
        stopPositions = stops[offset];
        while stopIndex < len(stopPositions) and startIndex < len(startPositions):
            if stopPositions[stopIndex] > startPositions[startIndex]:
                if stopPositions[stopIndex] not in rez:
                    rez[stopPositions[stopIndex]] = [startPositions[startIndex]]
                else:
                    rez[stopPositions[stopIndex]].append(startPositions[startIndex])
                startIndex += 1;
            else:
                stopIndex += 1;
        rezults.append(rez)

    findFurthestCodonPairs(rezults)
    return rezults;

def findFurthestCodonPairs(positions):
    rezults = [];
    for group in positions:
        rez = []
        for stopPositions in group:
            rez.append([min(group[stopPositions]), stopPositions]);
        rezults.append(rez);

    filterOutShorterThan(rezults, 100)
    return rezults;
    
def filterOutShorterThan(pairs, length):
    rezults = []
    for group in pairs:
        rezults.append(list(filter(lambda pair: pair[1] - pair[0] + 3 >= length, group)))

    frequencies(rezults)
    # print(sequence[rezults[2][0][0]:rezults[2][0][1] + 3].translate())
    return rezults;

codonFrequencies = {};
didoconFrequencies = {};
aminoFrequencies = {};
diaminoFrequencies = {};

def frequencies(pairs):
    for group in pairs:
        for pair in group:
            for offset in range(3):
                for codon in re.findall(r".{1,3}", str(sequence[pair[0] + offset :pair[1] + 3])):
                    if len(codon) == 3:
                        codonFrequencies[codon] += 1
                for dicodon in re.findall(r".{1,6}", str(sequence[pair[0] + offset :pair[1] + 3])):
                    if len(dicodon) == 6:
                        didoconFrequencies[dicodon] += 1

sequence = '';



def genAllCodons():
    vals = ['A', 'T', 'G', 'C']
    for first in vals:
        for second in vals:
            for third in vals:
                codonFrequencies[first + second + third] = 0;
                for fourth in vals:
                    for fifth in vals:
                        for sixth in vals:
                            didoconFrequencies[first + second + third + fourth + fifth + sixth] = 0;




failai = ['./data/bacterial1.fasta', './data/bacterial2.fasta', './data/bacterial3.fasta', './data/bacterial4.fasta',
'./data/mamalian1.fasta', './data/mamalian2.fasta', './data/mamalian3.fasta', './data/mamalian4.fasta',]
genAllCodons();


headerscodon = ['']
for freq in codonFrequencies:
    headerscodon.append(freq);

headersdicodon = ['']
for freq in didoconFrequencies:
    headersdicodon.append(freq);


dataCodon = [headerscodon];
dataDicodon = [headersdicodon];


somethingCodon = [];
somethingDicodon = [];
for failas in failai:
  
    genAllCodons();
    fasta_sequences = SeqIO.parse(open(failas),'fasta')
    for fasta in fasta_sequences:
        name, sequence = fasta.id, fasta.seq;
        # new_sequence = some_function(sequence)
        # write_fasta(out_file)
        findCodonPairs(sequence);

        sequence = sequence.reverse_complement();
        findCodonPairs(sequence);

        totalcodons = 0;
        totaldicodons = 0;
        for freq in codonFrequencies:
            totalcodons += codonFrequencies[freq];
        for freq in didoconFrequencies:
            totaldicodons += didoconFrequencies[freq];

        something = {}
        something['total'] = totalcodons;
        for freq in codonFrequencies:
            something[freq] = codonFrequencies[freq]
            codonFrequencies[freq] /= totalcodons;
            # codonFrequencies[freq] = str(codonFrequencies[freq]);
        
        somethingCodon.append(something);

        something = {}
        something['total'] = totaldicodons;
        for freq in didoconFrequencies:
            something[freq] = didoconFrequencies[freq]
            didoconFrequencies[freq] /= totaldicodons;
            # didoconFrequencies[freq] = str(didoconFrequencies[freq]);
        somethingDicodon.append(something)

        kazkas = []
        kazkas.append(failas.split('/')[2])
        for freq in codonFrequencies:
            kazkas.append(codonFrequencies[freq]);

        dataCodon.append(kazkas);
      
        kazkas = []
        kazkas.append(failas.split('/')[2])
        for freq in didoconFrequencies:
            kazkas.append(didoconFrequencies[freq]);

        dataDicodon.append(kazkas)


#  = list(zip(*map(lambda x: str(x), dataCodon)));
t_matrix = numpy.transpose(dataCodon)
# print(t_matrix[1])
# quit();
# for l in t_matrix:
#     print(' '.join(l));

f = open("codonFrequencies.csv", "w")
for line in t_matrix:

    f.write(','.join(line));
    f.write('\n');
f.close()


t_matrix = numpy.transpose(dataDicodon)
f = open("dicodonFrequencies.csv", "w")
for line in t_matrix:
    f.write(','.join(line));
    f.write('\n');
f.close()

for i in range(1, len(dataCodon) - 1):
    for j in range(i + 1, len(dataCodon)):
        nzn = 0
        for k in range(1, len(dataCodon[i])):
            nzn += (dataCodon[i][k] - dataCodon[j][k]) ** 2;

        nzn = sqrt(nzn);
        # print(dataCodon[i][0], dataCodon[j][0], nzn);



def medziui(seq):
    naujaSuma = {}
    for key in seq[0]:
        for other in seq[:4]:
            if key not in naujaSuma:
                naujaSuma[key] = 0;
            naujaSuma[key] += other[key];


    for key in naujaSuma:
        if key != 'total':
            naujaSuma[key] /= naujaSuma['total'];

    bak = [naujaSuma]
    naujaSuma = {}
    for key in seq[0]:
        for other in seq[4:]:
            if key not in naujaSuma:
                naujaSuma[key] = 0;
            naujaSuma[key] += other[key];


    for key in naujaSuma:
        if key != 'total':
            naujaSuma[key] /= naujaSuma['total'];

    bak.append(naujaSuma);

    return bak;

naujaSuma2 = {}
for key in somethingDicodon[0]:
    for other in somethingDicodon[:4]:
        if key not in naujaSuma2:
            naujaSuma2[key] = 0;
        naujaSuma2[key] += other[key];
for key in naujaSuma2:
    if key != 'total':
        naujaSuma2[key] /= naujaSuma2['total'];

bak = medziui(somethingDicodon);
rezu=[];
for bakte in bak[0]:
    if (bakte == 'total'):
        continue
    bf = bak[0][bakte]
    rez=[bakte]
    for mam in bak[1]:
        mf = bak[1][mam]
        if (mam == 'total'):
            continue
        rez.append(str(abs(bf-mf)));
    rezu.append(rez);



kitas = open('medziui.txt', "w")

kitas.write(str(len(rezu)))
kitas.write('\n')
print(len(rezu))
for r in rezu:
    kitas.write(' '.join(r))
    kitas.write('\n')

kitas.close()